package com.rana_aditya.parent;

import android.app.Activity;
import android.os.Bundle;



public class aboutapp extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

    }
}
